
import { parseNeisHtml } from './parser.js';
import { calculateGrades } from './calculator.js';

document.addEventListener('DOMContentLoaded', () => {
    const dropZone = document.getElementById('uploadSection');
    const fileInput = document.getElementById('fileInput');
    const dashboard = document.getElementById('dashboard');
    const uploadSection = document.getElementById('uploadSection');
    const instructionSection = document.getElementById('instructionSection');
    const backBtn = document.getElementById('backBtn');

    // Back Button Logic
    backBtn.addEventListener('click', () => {
        dashboard.classList.add('hidden');
        uploadSection.classList.remove('hidden');
        instructionSection.classList.remove('hidden');
        fileInput.value = ''; // Reset input
    });

    // Drag & Drop Handlers
    dropZone.addEventListener('click', () => fileInput.click());

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('dragover');
    });

    dropZone.addEventListener('dragleave', () => {
        dropZone.classList.remove('dragover');
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('dragover');
        if (e.dataTransfer.files.length) {
            handleFile(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length) {
            handleFile(e.target.files[0]);
        }
    });

    function handleFile(file) {
        if (!file.name.endsWith('.html') && !file.name.endsWith('.htm')) {
            alert('HTML 파일을 업로드해주세요.');
            return;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const buffer = e.target.result;
                let decoder = new TextDecoder('utf-8');
                let content = decoder.decode(buffer);

                // Simple heuristic to check if decoding was successful
                // NEIS files definitely contain "학기" or "과목" or "성명"
                if (!content.includes('학기') && !content.includes('과목') && !content.includes('성명')) {
                    // Try EUC-KR
                    console.log('UTF-8 parsing seemed to fail (keywords not found). Retrying with EUC-KR...');
                    decoder = new TextDecoder('euc-kr');
                    content = decoder.decode(buffer);
                }

                processContent(content);
            } catch (err) {
                console.error(err);
                alert('파일을 읽는 중 오류가 발생했습니다: ' + err.message);
            }
        };
        reader.readAsArrayBuffer(file);
    }

    function processContent(html) {
        // 1. Parse
        const { records, seteuk, creative, behavior } = parseNeisHtml(html);

        if (!records || records.length === 0) {
            alert('성적 데이터를 찾을 수 없습니다.');
            return;
        }

        // 2. Calculate
        const result = calculateGrades(records);

        // 3. Render
        renderDashboard(result, seteuk, creative, behavior);

        // Switch View
        uploadSection.classList.add('hidden');
        if (instructionSection) instructionSection.classList.add('hidden');
        dashboard.classList.remove('hidden');

        // Setup Export Buttons
        document.getElementById('btnDownloadTxt').onclick = () => downloadTxt(result, seteuk, creative, behavior);
        document.getElementById('btnPrint').onclick = () => window.print();
    }

    function renderDashboard(data, seteuk, creative, behavior) {
        // Yonsei Score
        const elYonseiScore = document.getElementById('yonseiScore');
        if (elYonseiScore) elYonseiScore.textContent = data.yonsei.finalScore.toFixed(2);

        const elYonseiCommon = document.getElementById('yonseiCommon');
        if (elYonseiCommon) elYonseiCommon.textContent = data.yonsei.common.term.toFixed(2);

        const elYonseiGen = document.getElementById('yonseiGeneral');
        if (elYonseiGen) elYonseiGen.textContent = data.yonsei.general.term.toFixed(2);

        const elYonseiCar = document.getElementById('yonseiCareer');
        if (elYonseiCar) elYonseiCar.textContent = data.yonsei.career.term.toFixed(2);

        const elYonseiPenalty = document.getElementById('yonseiPenalty');
        if (elYonseiPenalty) elYonseiPenalty.textContent = '-' + data.yonsei.penalty.toFixed(2);

        // Simple GPA
        const elGpaAll = document.getElementById('gpaAll');
        if (elGpaAll) elGpaAll.textContent = data.simple.all.toFixed(2);

        const elGpaKem = document.getElementById('gpaKem');
        if (elGpaKem) elGpaKem.textContent = data.simple.kem.toFixed(2);

        const elGpaKems = document.getElementById('gpaKems');
        if (elGpaKems) elGpaKems.textContent = data.simple.kems.toFixed(2);

        const elGpaKemss = document.getElementById('gpaKemss');
        if (elGpaKemss) elGpaKemss.textContent = data.simple.kemss.toFixed(2);

        // Table
        const tbody = document.getElementById('gradeTableBody');
        tbody.innerHTML = '';

        data.details.forEach(r => {
            const tr = document.createElement('tr');

            // Type Badge
            let badgeClass = 'badge-common';
            if (r.type === 'General') badgeClass = 'badge-general';
            if (r.type === 'Career') badgeClass = 'badge-career';

            tr.innerHTML = `
                <td>${r.semester}</td>
                <td><span class="badge ${badgeClass}">${r.category}</span></td>
                <td>${r.name}</td>
                <td>${r.credit}</td>
                <td>${r.rank || '-'}</td>
                <td>${r.achievement}</td>
                <td>${r.raw ? r.raw : '-'}</td>
                <td>${r.mean ? r.mean : '-'}</td>
                <td>${r.std ? r.std : '-'}</td>
            `;
            tbody.appendChild(tr);
        });

        // Render Byte Calculator
        renderByteCalculator(creative, seteuk, behavior);

        // Render SeTeuk (if container exists)
        const seteukContainer = document.getElementById('seteukContainer');
        if (seteukContainer) {
            seteukContainer.innerHTML = ''; // Clear previous
            let hasContent = false;

            if (seteuk && (Object.keys(seteuk.subjects).length > 0 || seteuk.individual)) {
                hasContent = true;
                for (const [subject, content] of Object.entries(seteuk.subjects)) {
                    createDetailItem(seteukContainer, subject, content);
                }
                if (seteuk.individual) {
                    createDetailItem(seteukContainer, "개인별 세부능력", seteuk.individual);
                }
            }

            // Add Behavior to SeTeuk Card section as well? Or separate?
            // The user asked for "behavior" to be extracted. It fits in "SeTeuk & Remarks" visually.
            if (behavior) {
                hasContent = true;
                createDetailItem(seteukContainer, "행동특성 및 종합의견", behavior);
            }

            if (!hasContent) {
                seteukContainer.innerHTML = '<p style="color: grey;">세부능력 및 특기사항 데이터를 찾을 수 없습니다.</p>';
            }
        }
    }

    function createDetailItem(container, title, content) {
        const div = document.createElement('div');
        div.className = 'detail-item';
        div.style.textAlign = 'left';
        div.style.marginBottom = '1rem';
        div.innerHTML = `<strong style="color: var(--accent-color);">${title}</strong><p style="margin-top:0.5rem; font-size: 0.9rem; color: #d1d5db; white-space: pre-wrap;">${content}</p>`;
        container.appendChild(div);
    }

    function getByteLength(str) {
        if (!str) return 0;
        let b = 0;
        for (let i = 0; i < str.length; i++) {
            const code = str.charCodeAt(i);
            // NEIS: Hangul = 3 bytes, Enter = 2 bytes, Others = 1 byte
            if (code === 10) b += 2; // LF
            else if (code > 127) b += 3;
            else b += 1;
        }
        return b;
    }

    function renderByteCalculator(creative, seteuk, behavior) {
        const container = document.getElementById('byteContainer');
        if (!container) return;
        container.innerHTML = '';

        const items = [
            { label: '자율활동', content: creative?.autonomy, max: 1500 },
            { label: '동아리활동', content: creative?.club, max: 1500 },
            { label: '진로활동', content: creative?.career, max: 2100 },
            { label: '개인별 세특', content: seteuk?.individual, max: 1500 },
            { label: '행동특성', content: behavior, max: 1500 } // Typical limit
        ];

        // Add Subjects if available
        if (seteuk && seteuk.subjects) {
            Object.entries(seteuk.subjects).forEach(([subj, content]) => {
                items.push({ label: subj, content: content, max: 1500 });
            });
        }

        items.forEach(item => {
            const div = document.createElement('div');
            div.className = 'byte-item';

            // Initial Calc
            const initialBytes = getByteLength(item.content || '');
            const initialPercent = Math.min((initialBytes / item.max) * 100, 100);
            let colorClass = 'progress-safe';
            if (initialBytes > item.max) colorClass = 'progress-danger';
            else if (initialPercent > 90) colorClass = 'progress-warning';

            div.innerHTML = `
                <div class="byte-label">
                    <span>${item.label}</span>
                    <span class="byte-value-text ${initialBytes > item.max ? 'text-red-400' : ''}" style="${initialBytes > item.max ? 'color: var(--danger-color);' : ''}">${initialBytes} / ${item.max} Byte</span>
                </div>
                <div class="progress-container">
                    <div class="progress-bar ${colorClass}" style="width: ${initialPercent}%"></div>
                </div>
                <textarea class="byte-textarea">${item.content || ''}</textarea>
            `;

            // Add Interactivity
            const textarea = div.querySelector('textarea');
            const valueDisplay = div.querySelector('.byte-value-text');
            const progressBar = div.querySelector('.progress-bar');

            textarea.addEventListener('input', () => {
                const currentBytes = getByteLength(textarea.value);
                const currentPercent = Math.min((currentBytes / item.max) * 100, 100);

                valueDisplay.textContent = `${currentBytes} / ${item.max} Byte`;
                progressBar.style.width = `${currentPercent}%`;

                // Update Colors
                progressBar.className = 'progress-bar'; // reset
                valueDisplay.style.color = '';

                if (currentBytes > item.max) {
                    progressBar.classList.add('progress-danger');
                    valueDisplay.style.color = 'var(--danger-color)';
                } else if (currentPercent > 90) {
                    progressBar.classList.add('progress-warning');
                } else {
                    progressBar.classList.add('progress-safe');
                }
            });

            container.appendChild(div);
        });
    }

    function downloadTxt(data, seteuk, creative, behavior) {
        let text = `[나이스 생기부 분석 리포트]\n\n`;
        text += `1. 점수 요약\n`;
        text += `- 연세대 환산점수: ${data.yonsei.finalScore.toFixed(2)}\n`;
        text += `- 단순 평균등급(전과목): ${data.simple.all.toFixed(2)}\n\n`;

        text += `2. 과목별 세부 성적\n`;
        data.details.forEach(r => {
            text += `${r.semester} | ${r.category} | ${r.name}: ${r.rank ? r.rank + '등급' : r.achievement} (단위:${r.credit})\n`;
        });
        text += `\n`;

        text += `3. 창의적 체험활동\n`;
        text += `[자율활동]\n${creative?.autonomy || ''}\n\n`;
        text += `[동아리활동]\n${creative?.club || ''}\n\n`;
        text += `[진로활동]\n${creative?.career || ''}\n\n`;

        text += `4. 세부능력 및 특기사항\n`;
        if (seteuk && seteuk.subjects) {
            Object.entries(seteuk.subjects).forEach(([subj, content]) => {
                text += `[${subj}]\n${content}\n\n`;
            });
        }
        if (seteuk?.individual) {
            text += `[개인별 세특]\n${seteuk.individual}\n\n`;
        }

        text += `5. 행동특성 및 종합의견\n`;
        text += `${behavior || ''}\n`;

        const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `생기부_분석_${new Date().toISOString().slice(0, 10)}.txt`;
        link.click();
    }
});
