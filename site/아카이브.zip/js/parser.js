
/**
 * NEIS HTML Parser
 * Extracts student records from the uploaded HTML file.
 */

export function parseNeisHtml(htmlContent) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(htmlContent, 'text/html');

    // Find all tables
    const tables = Array.from(doc.querySelectorAll('table'));

    // We are looking for the "교과학습발달상황" -> "세부능력 및 특기사항" or "성적" tables.
    // Usually NEIS structure is complex. We look for headers.

    const records = [];

    tables.forEach(table => {
        // Check headers to identify table type
        const headers = Array.from(table.querySelectorAll('thead th, tbody tr:first-child td')).map(th => th.textContent.replace(/\s+/g, '').trim());
        const headerText = headers.join('|');

        // Identify Grade Tables
        // Key columns: 학기, 교과, 과목, 단위(학점), 원점수/과목평균(표준편차), 성취도(수강자수), 석차등급
        // Note: Headers might vary slightly by year.
        const isGradeTable = (headerText.includes('학기') && headerText.includes('교과') && headerText.includes('과목') && (headerText.includes('단위') || headerText.includes('학점')));

        if (isGradeTable) {
            // Parse Rows
            const rows = Array.from(table.querySelectorAll('tbody tr'));

            // Skip header rows if they are in tbody
            // Basic heuristic: check if first cell is "학기"

            rows.forEach(row => {
                const cells = Array.from(row.querySelectorAll('td'));
                if (cells.length < 5) return; // invalid row

                // Map columns based on index (assuming standard order, or heuristic map)
                // Standard Order usually: 학기, 교과, 과목, 단위(학점), 원점수..., 성취도..., 석차등급, 비고
                // BUT sometimes headers are merged.
                // Let's rely on the cleaned text content.

                // We need to robustly find indexes.
                // Re-scan headers for this specific table (thead usually)
                const ths = Array.from(table.querySelectorAll('thead th'));
                let map = {
                    semester: -1, kyogwa: -1, name: -1, credit: -1,
                    raw: -1, achievement: -1, rank: -1
                };

                ths.forEach((th, idx) => {
                    const txt = th.textContent.replace(/\s+/g, '');
                    if (txt.includes('학기')) map.semester = idx;
                    else if (txt.includes('교과')) map.kyogwa = idx;
                    // '과목' might appear in '원점수/과목평균', so we must be careful.
                    // Check strict equality or ensure it doesn't contain '원점수'/'평균'
                    else if (txt.includes('과목') && !txt.includes('평균') && !txt.includes('원점수')) map.name = idx;
                    else if (txt.includes('단위') || txt.includes('학점')) map.credit = idx;
                    else if (txt.includes('원점수')) map.raw = idx;
                    else if (txt.includes('성취도')) map.achievement = idx;
                    else if (txt.includes('석차등급')) map.rank = idx;
                });

                // If map is empty, maybe headers are in first TR?
                if (map.name === -1) {
                    // Try parsing first tr as header if we haven't already
                    // (Simplified logic: Assume standard layout if detection fails?)
                    // Let's assume standard layout for typical NEIS
                    // Index: 0:학기, 1:교과, 2:과목, 3:이수단위, 4:원점수/..., 5:성취도, 6:석차등급
                    map = { semester: 0, kyogwa: 1, name: 2, credit: 3, raw: 4, achievement: 5, rank: 6 };
                }

                // Extract Data
                const getText = (idx) => (cells[idx] ? cells[idx].textContent.trim() : "");

                const kyogwa = getText(map.kyogwa);
                const name = getText(map.name);
                const creditStr = getText(map.credit);
                const rawStr = getText(map.raw);
                const achStr = getText(map.achievement);
                const rankStr = getText(map.rank);

                if (!name || name === "과목") return; // Header row in tbody

                // Parse Credit
                const credit = parseFloat(creditStr) || 0;

                // Parse Raw/Mean/Std
                // Format: "95/78.5(15.2)"
                let raw = null, mean = null, std = null;
                if (rawStr && !rawStr.includes("·")) {
                    const cleanRaw = rawStr.replace(' ', '');
                    if (cleanRaw.includes('/')) {
                        const parts = cleanRaw.split('/');
                        raw = parseFloat(parts[0]);
                        if (parts[1]) {
                            const stats = parts[1];
                            if (stats.includes('(')) {
                                const [m, s] = stats.split('(');
                                mean = parseFloat(m);
                                std = parseFloat(s.replace(')', ''));
                            } else {
                                mean = parseFloat(stats);
                            }
                        }
                    }
                }

                // Parse Achievement
                // Format: "A(252)" or "A"
                let achievement = achStr;
                if (achievement.includes('(')) {
                    achievement = achievement.split('(')[0].trim();
                }

                // Parse Rank
                let rank = null;
                if (rankStr && !isNaN(rankStr)) {
                    rank = rankStr;
                }

                records.push({
                    semester: getText(map.semester),
                    kyogwa,
                    name,
                    credit,
                    raw, mean, std,
                    achievement,
                    rank
                });
            });
        }
    });

    // --- Extract Creative Experiential Activities ---
    // Strategy: Find TDs with specific labels and get the text of the next TD.

    const creative = {
        autonomy: '',
        club: '',
        career: ''
    };

    // Helper to find text in next cell
    const allCells = Array.from(doc.querySelectorAll('td'));
    allCells.forEach((td, i) => {
        const txt = td.textContent.replace(/\s+/g, '');
        if (txt === '자율활동' || txt.includes('자율활동특기사항')) {
            if (allCells[i + 1]) creative.autonomy += allCells[i + 1].textContent.trim();
        }
        else if (txt === '동아리활동' || txt.includes('동아리활동특기사항')) {
            if (allCells[i + 1]) creative.club += allCells[i + 1].textContent.trim();
        }
        else if (txt === '진로활동' || txt.includes('진로활동특기사항')) {
            if (allCells[i + 1]) creative.career += allCells[i + 1].textContent.trim();
        }
    });

    // --- Extract Special Remarks (SeTeuk) ---
    const seteuk = {
        subjects: {},
        individual: ''
    };

    // Behavior Characteristics (행동특성)
    let behavior = '';

    // Strategy 1: Find table with header "행동특성"
    const allThs = Array.from(doc.querySelectorAll('th, td')); // sometimes headers are tds
    for (let i = 0; i < allThs.length; i++) {
        const txt = allThs[i].textContent.replace(/\s+/g, '');
        if (txt.includes('행동특성') && txt.includes('종합의견')) {
            // Usually the content is in a cell nearby (next row or same row next cell)
            // But usually it's a large merged cell below.
            // Let's look for a large text block in the following structure.
            // Or simpler: The content usually resides in a div with class 'wsBs' inside that table or just next to it.
        }
    }

    const detailSections = Array.from(doc.querySelectorAll('div.wsBs'));

    detailSections.forEach((section, idx) => {
        const text = section.innerText || section.textContent;

        // Strategy 2: Behavior is often the LAST wsBs section or contains keywords
        // Let's gather Subjects first
        if (text.length > 50) {
            const entries = text.split(/\n\s*\n/);

            entries.forEach(entry => {
                entry = entry.trim();
                const isSubject = entry.includes(':');

                if (isSubject) {
                    const firstColon = entry.indexOf(':');
                    let subjectName = entry.substring(0, firstColon).trim();
                    const content = entry.substring(firstColon + 1).trim();

                    if (subjectName.includes('학기)')) {
                        subjectName = subjectName.split('학기)').pop().trim();
                    }

                    if (subjectName && content.length > 10) {
                        if (subjectName.includes('개인별')) {
                            seteuk.individual += content + '\n';
                        } else {
                            seteuk.subjects[subjectName] = content;
                        }
                    }
                } else {
                    // If it's a long block without colon, it might be Behavior or Individual
                    // If this is the LAST section and has no colons, it's likely Behavior
                    if (idx === detailSections.length - 1 && text.length > 100) {
                        behavior += entry + '\n';
                    }
                }
            });
        }
    });

    // Final fallback for Behavior if regex failed but we found a specific cell
    // (Simplification: relying on the last section heuristic from python script for now)

    return { records, seteuk, creative, behavior: behavior.trim() };
}
